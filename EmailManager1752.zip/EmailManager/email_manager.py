import tkinter as tk
import tkinter.scrolledtext as tkst
from tkinter import messagebox

import message_manager as messages
import font_manager as fonts

from read_message import ReadMessage
from new_message import NewMessage
from label_messages import LabelMessages


def set_text(text_area, content):
    text_area["state"] = "normal"
    text_area.delete("1.0", tk.END)
    text_area.insert(1.0, content)
    text_area["state"] = "disabled"


class EmailManager():
    def __init__(self, window):
        self.window = window
        self.window.geometry("850x400")
        self.window.title("Email Manager")


        list_messages_btn = tk.Button(window, text="List Messages", command=self.list_messages)
        list_messages_btn.grid(row=1, column=0, padx=10, pady=10)

        read_message_btn = tk.Button(window, text="Read Message:", command=self.read_message)
        read_message_btn.grid(row=1, column=1, padx=10, pady=10)

        self.id_txt = tk.Entry(window, width=3)
        self.id_txt.grid(row=1, column=2, padx=10, pady=10)

        new_message_btn = tk.Button(window, text="New Message", command=self.new_message)
        new_message_btn.grid(row=1, column=3, padx=10, pady=10)


        sender_lbl = tk.Label(window, text="Filter by sender:")
        sender_lbl.grid(row=1, column=5, padx=10, pady=10)

        self.selected_sender = tk.StringVar(window)
        self.selected_sender.set("All")

        sender_list = ["All"] + messages.get_all_senders()
        self.sender_menu = tk.OptionMenu(window, self.selected_sender, *sender_list, command=lambda _: self.list_messages())
        self.sender_menu.grid(row=1, column=6, padx=10, pady=10)


        label_messages_btn = tk.Button(window, text="Label Messages", command=self.label_messages)
        label_messages_btn.grid(row=1, column=4, padx=10, pady=10)

        self.list_txt = tkst.ScrolledText(window, width=70, height=12, wrap="none")
        self.list_txt.grid(row=2, column=0, columnspan=6, sticky="W", padx=10, pady=10)

        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10))
        self.status_lbl.grid(row=3, column=0, columnspan=4, sticky="W", padx=10, pady=10)

        search_lbl = tk.Label(window, text="Search:")
        search_lbl.grid(row=0, column=1, padx=10, pady=10)

        self.search_txt = tk.Entry(window, width=15)
        self.search_txt.grid(row=0, column=2, padx=5, pady=10)

        search_btn = tk.Button(window, text="Search", command=self.search_messages)
        search_btn.grid(row=0, column=3, padx=5, pady=10)


        self.list_messages()


    def read_message(self):
        message_id_string = self.id_txt.get()
        valid = False
        if len(message_id_string) > 0:
            message_id = int(message_id_string)
            sender = messages.get_sender(message_id)
            if sender is not None:
                ReadMessage(tk.Toplevel(window), message_id)
                valid = True
        if not valid:
            messagebox.showinfo("INVALID ID", "Select a valid message ID")
        self.status_lbl.configure(text="Read Message button was clicked!")

    def list_messages(self):
        # Get the selected sender from the dropdown menu
        chosen_sender = self.selected_sender.get()

        # If "All" is selected, show all messages
        if chosen_sender == "All":
            message_list = messages.list_all()
            status_message = "All messages are currently listed."
        else:
            # Get the full list of messages as lines of text
            all_lines = messages.list_all().splitlines()

            # The first two lines are the table headers
            header = all_lines[0] + "\n" + all_lines[1]

            # Create a list to hold only the messages that match the selected sender
            filtered_messages = []

            # Go through each message line after the header
            for line in all_lines[2:]:
                if chosen_sender in line:
                    filtered_messages.append(line)

            # Put the header and filtered messages together
            message_list = header + "\n" + "\n".join(filtered_messages)
            status_message = f"Messages from '{chosen_sender}' currently listed."

        # Show the filtered list in the message display area
        set_text(self.list_txt, message_list)

        # Update the status label at the bottom
        self.status_lbl.config(text=status_message)

    def new_message(self):
        NewMessage(tk.Toplevel(window))
        self.status_lbl.configure(text="New Message button was clicked!")

    def label_messages(self):
        LabelMessages(tk.Toplevel(window))
        self.status_lbl.configure(text="Label Messages button was clicked!")

    def search_messages(self):
        # Get the text typed in the search box and make it lowercase
        search_text = self.search_txt.get().strip().lower()

        # If nothing is typed, show a warning and stop
        if search_text == "":
            self.status_lbl.config(text="Search field is empty")
            return

        # Get the full list of messages as lines
        all_lines = messages.list_all().splitlines()

        # The first two lines are the header (column titles)
        header = all_lines[0] + "\n" + all_lines[1]

        # Make a list to store any matching messages
        matching_lines = []

        # Go through each line after the header
        for line in all_lines[2:]:
            # Get the message ID from the start of the line
            message_id = int(line.split()[0])

            # Get sender, subject, and content of the message (all lowercase for comparison)
            sender = messages.get_sender(message_id).lower()
            subject = messages.get_subject(message_id).lower()
            content = messages.get_content(message_id).lower()

            # If the search text is found in any of those parts, it's a match
            if search_text in sender or search_text in subject or search_text in content:
                matching_lines.append(line)

        # If we found some matches, show them
        if len(matching_lines) > 0:
            result_text = header + "\n" + "\n".join(matching_lines)
            self.status_lbl.config(text=f"Found messages matching '{search_text}'")
        else:
            # If no match was found, show message and just display header
            result_text = header + "\nNo matching messages found."
            self.status_lbl.config(text=f"No results for '{search_text}'")

        # Show the result in the text box
        set_text(self.list_txt, result_text)



if __name__ == "__main__":
    window = tk.Tk()
    fonts.configure()
    EmailManager(window)
    window.mainloop()
