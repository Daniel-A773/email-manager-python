import tkinter as tk
import tkinter.scrolledtext as tkst

import message_manager as messages
import font_manager as fonts

def set_text(text_area, content):
    text_area["state"] = "normal"
    text_area.delete("1.0", tk.END)
    text_area.insert(1.0, content)
    text_area["state"] = "disabled"


class LabelMessages(): # defines the "new_message" class, responsible for reading emails sent
    def __init__(self, window):
        self.window = window # responsible for storing the window (Tkinter)
        self.window.geometry("800x320") # adjusts the window size to the number set in the brackets
        self.window.title(f"Label Messages")

        list_messages_btn = tk.Button(window, text="List All Messages Labelled:", command=self.list_filtered_messages)
        list_messages_btn.grid(row=0, column=0, padx=10, pady=10)

        self.label_txt = tk.Entry(window, width=6)
        self.label_txt.grid(row=0, column=2, padx=10, pady=10)

        add_label_to_message_btn = tk.Button(window, text="Add Label to Message", command=self.add_label)
        add_label_to_message_btn.grid(row=0, column=3, padx=10, pady=10)

        self.id_txt = tk.Entry(window, width=4)
        self.id_txt.grid(row=0, column=4, padx=10, pady=10)

        close_btn = tk.Button(window, text="Close", command=self.close)
        close_btn.grid(row=0, column=5, padx=10, pady=10)


        self.list_txt = tkst.ScrolledText(window, width=70, height=12, wrap="none")
        self.list_txt.grid(row=1, column=0, columnspan=7, sticky="W", padx=10, pady=10)

        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10))
        self.status_lbl.grid(row=2, column=0, columnspan=6, sticky="W", padx=10, pady=10)


        self.list_messages()

    def close(self):
        self.window.destroy()

    def list_messages(self):
        message_list = messages.list_all()
        set_text(self.list_txt, message_list)


    def list_filtered_messages(self):
        label_filter = self.label_txt.get().strip()
        message_list = messages.list_all(label_filter)
        set_text(self.list_txt, message_list)
        self.status_lbl.configure(text=f"Messages with label: '{label_filter}' listed.")

    def add_label(self):
        label = self.label_txt.get().strip()
        message_id_string = self.id_txt.get().strip()

        if not label or not message_id_string.isdigit():
            self.status_lbl.configure(text="Please provide a valid label and message ID!")
            return

        message_id = int(message_id_string)

        # Check if the message ID exists
        if message_id in messages.messages:
            # Apply the label to the message
            messages.set_label(message_id, label)
            self.status_lbl.configure(text=f"Label '{label}' applied to Message ID {message_id}.")
            self.list_messages()  # Refresh the message list
        else:
            self.status_lbl.configure(text=f"Message ID {message_id} not found.")


if __name__ == "__main__":  # only runs when this file is run as a standalone
    window = tk.Tk()  # create a TK object
    fonts.configure()  # configure the fonts
    LabelMessages(window, None)  # open the NewMessage GUI
    window.mainloop()  # run the window main loop, reacting to button presses, etc
