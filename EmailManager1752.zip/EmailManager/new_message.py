import tkinter as tk
import tkinter.scrolledtext as tkst

import message_manager
import font_manager as fonts

from message_manager import *

class NewMessage(): # defines the "new_message" class, responsible for reading emails sent
    def __init__(self, window):
        self.window = window # responsible for storing the window (Tkinter)
        self.window.geometry("550x320") # adjusts the window size to the number set in the brackets
        self.window.title(f"New Message")

        sender_lbl = tk.Label(window, text="Sender:") # this creates a label titled "Sender:" and it's put in the first column
        sender_lbl.grid(row=0, column=0, sticky="E", padx=10, pady=10)

        self.sender_txt = tk.Entry(window, width=40) # this creates a space for you to enter your name and it's placed in the first row and the second column, it is 5 columns long
        self.sender_txt.grid(row=0, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        recipient_lbl = tk.Label(window, text="Recipient:") # this creates a label called "To" placed in the second row, first column
        recipient_lbl.grid(row=1, column=0, sticky="E", padx=10, pady=10)

        self.recipient_txt = tk.Entry(window, width=40) # this creates a space for you to enter the name of the person you're sending the email to, it is in the second row and the first column
        self.recipient_txt.grid(row=1, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        subject_lbl = tk.Label(window, text="Subject:") # creates a label titled "Subject" in the third row, first column
        subject_lbl.grid(row=2, column=0, sticky="E", padx=10, pady=10)

        self.subject_txt = tk.Entry(window, width=40) # creates a space for you to write the subject of the email being sent in the third row, second column, spans 5 columns
        self.subject_txt.grid(row=2, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        self.content_txt = tkst.ScrolledText(window, width=40, height=6, wrap="word") # creates a scrollable area for the email/message you want to send
        self.content_txt.grid(row=3, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        send_btn = tk.Button(window, text="Send", width=15, command=self.send_message) # creates a button named "send" which utilizes "delete_message" when pressed. responsible for deleting messages/emails
        send_btn.grid(row=4, column=5, padx=10, pady=10)

        close_btn = tk.Button(window, text="Close", width=15, command=self.close) # creates a button named "cancel" utilizes the method "close".
        close_btn.grid(row=4, column=0, padx=10, pady=10)

    def close(self):
        self.window.destroy()

    def send_message(self):
        sender = self.sender_txt.get().strip()  # Get text from Entry
        recipient = self.recipient_txt.get().strip()
        subject = self.subject_txt.get().strip()
        content = self.content_txt.get("1.0", tk.END).strip()

        if not sender or not recipient or not subject or not content:
            tk.messagebox.showwarning("Warning", "All fields must be filled out!")
            return

        message_manager.new_message(sender, recipient, subject, content)

        tk.messagebox.showinfo("Success", "Message sent successfully!")
        self.window.destroy()




if __name__ == "__main__":  # only runs when this file is run as a standalone
    window = tk.Tk()  # create a TK object
    fonts.configure()  # configure the fonts
    NewMessage(window, None)  # open the NewMessage GUI
    window.mainloop()  # run the window main loop, reacting to button presses, etc
