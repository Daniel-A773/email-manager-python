import tkinter as tk # imports tkinter GUI and labels it "tk"
import tkinter.scrolledtext as tkst # imports "scrolled text", text box that also has a scroll bar

import message_manager as messages # imports code from message_manager to handle anything regarding messages, labeled "messages"
import font_manager as fonts # imports code from font_manager, handles the font style in the email UI


class ReadMessage(): # defines the "read_message" class, responsible for reading emails sent
    def __init__(self, window, message_id): # defines constructor which is going to initialize(__init__) the GUI, the "message ID" is the id of message that is being read
        self.message_id = message_id # responsible for storing the message ID

        self.window = window # responsible for storing the window (Tkinter)
        self.window.geometry("500x320") # adjusts the window size to the number set in the brackets
        self.window.title(f"Read Message {message_id}") # responsible for the name of the window, in this case it is "read message" then after follows whatever the message ID is

        sender_lbl = tk.Label(window, text="From:") # this creates a label titled "From:" and it's put in the first column
        sender_lbl.grid(row=0, column=0, sticky="E", padx=10, pady=10)

        self.sender_txt = tk.Entry(window, width=40) # this creates a space for you to enter your name and it's placed in the first row and the second column, it is 5 columns long
        self.sender_txt.grid(row=0, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        recipient_lbl = tk.Label(window, text="To:") # this creates a label called "To" placed in the second row, first column
        recipient_lbl.grid(row=1, column=0, sticky="E", padx=10, pady=10)

        self.recipient_txt = tk.Entry(window, width=40) # this creates a space for you to enter the name of the person you're sending the email to, it is in the second row and the first column
        self.recipient_txt.grid(row=1, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        subject_lbl = tk.Label(window, text="Subject:") # creates a label titled "Subject" in the third row, first column
        subject_lbl.grid(row=2, column=0, sticky="E", padx=10, pady=10)

        self.subject_txt = tk.Entry(window, width=40) # creates a space for you to write the subject of the email being sent in the third row, second column, spans 5 columns
        self.subject_txt.grid(row=2, column=1, columnspan=5, sticky="W", padx=10, pady=10)

        self.content_txt = tkst.ScrolledText(window, width=48, height=6, wrap="word") # creates a scrollable area for the email/message you want to send
        self.content_txt.grid(row=3, column=0, columnspan=6, sticky="W", padx=10, pady=10)

        subject_lbl = tk.Label(window, text="New priority (1-5):") # creates a label to enter the priority of the message/email, fifth row, first column
        subject_lbl.grid(row=4, column=0, columnspan=2, sticky="E", padx=10, pady=10)

        self.priority_txt = tk.Entry(window, width=3) # creates area to enter number priority, small as width is only 3
        self.priority_txt.grid(row=4, column=2, sticky="W", padx=10, pady=10)

        update_btn = tk.Button(window, text="Update", command=self.update_priority) # creates a button named "update" which uses method "update_priority" when pressed.
        update_btn.grid(row=4, column=3, sticky="W", padx=10, pady=10)

        delete_btn = tk.Button(window, text="Delete", command=self.delete_message) # creates a button named "delete" which uses "delete_message" when pressed. responsible for deleting messages/emails
        delete_btn.grid(row=4, column=4, padx=10, pady=10)

        close_btn = tk.Button(window, text="Close", command=self.close) # creates a button named "close" uses the method "close".
        close_btn.grid(row=4, column=5, padx=10, pady=10)

        if message_id is not None:
            sender = messages.get_sender(message_id) # if message id is not "none", no value assigned, then it will access the sender
            if sender is not None: # if the sender field is not empty, it will proceed
                self.sender_txt.insert(tk.END, sender) # adds sender name to "entry"
                self.sender_txt.configure(state='readonly') # stops user from changing the sender's name
                self.recipient_txt.insert(tk.END, messages.get_recipient(message_id))
                self.recipient_txt.configure(state='readonly') # fills the recipient text field, becomes read only
                self.subject_txt.insert(tk.END, messages.get_subject(message_id))
                self.subject_txt.configure(state='readonly') # fills the subject text field and makes it read only
                self.content_txt.insert(tk.END, messages.get_content(message_id)) # puts the message/email into a scrollabe text box
            else:
                self.content_txt.insert(tk.END, 'No such message') # shows "No such message" if there's no message
        self.content_txt["state"] = "disabled" # stops user from editing the message

    def delete_message(self):
        if self.message_id is not None:
            messages.delete_message(self.message_id)
        self.close() # deletes the message and closes the window

    def update_priority(self):
        if self.message_id is not None:
            messages.set_priority(self.message_id, int(self.priority_txt.get())) # updates the priority of the message

    def close(self):
        self.window.destroy() # closes the window


if __name__ == "__main__":  # only runs when this file is run as a standalone
    window = tk.Tk()  # create a TK object
    fonts.configure()  # configure the fonts
    ReadMessage(window, None)  # open the ReadMessage GUI
    window.mainloop()  # run the window main loop, reacting to button presses, etc
